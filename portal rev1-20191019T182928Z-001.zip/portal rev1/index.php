<?php
session_start();
?>
<!doctype html>
<html lang="en-gb" class="no-js">
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!--[if lt IE 9]> 
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
<title>ONLINE SERVICE</title>


<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen" />
<link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="/portal/css/datepicker.css">

<link href="css/animate.css" rel="stylesheet" media="screen">
<!-- Owl Carousel Assets -->
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" href="css/styles.css" />
<!-- Font Awesome -->
<link href="font/css/font-awesome.min.css" rel="stylesheet">

<!-- <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.min.css" />
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker3.min.css" />

<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="/portal/js/bootstrap-datepicker.js"></script>
 -->
</head>

<body>





<header class="header">
  <div class="container">
    <nav class="navbar navbar-inverse" role="navigation">
     
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        
        <a href="/portal/index.html" class="navbar-brand scroll-top logo  animated bounceInLeft"><b><i></i>PORTAL</b></a> </div>
      <!--/.navbar-header-->
      <div id="main-nav" class="collapse navbar-collapse">
       
        <ul class="nav navbar-nav" id="mainNav">
          
          <li class="active" id="firstLink"><a href="#home" class="scroll-link">Home</a></li>
          <li><a href="#work" class="scroll-link">Services</a></li>
          <li><a href="#team" class="scroll-link">Team</a></li>
          <li><a href="#aboutUs" class="scroll-link">About Us</a></li>
          <li><a href="#contact" class="scroll-link">Contact Us</a></li>
          <?php
          if($_SESSION['user']!=''){
           echo "<li><a href='php/logout.php' class='scroll-link'>Logout</a></li>";
          }
           else{
           echo "<li><a href='newlogin.html' class='scroll-link'>Login</a></li>";
            }
          ?>
        
          </ul>
      
      
      </div>
      <!--/.navbar-collapse--> 
    </nav>
    <!--/.navbar--> 
  </div>
  <!--/.container--> 
</header>
<!--/.header-->
<div id="top"></div>
<section id="home">
  <div class="banner-container"> <img src="images/bg1.jpg" alt="banner" />
    <div class="container banner-content">
      <div class="hero-text animated fadeInDownBig">
        <h1 class="responsive-headline" style="font-size: 40px;">Always At Your Service</h1>
        <a href="#work" class="arrow-link"> <i class="fa fa-arrow-circle-down fa-2x"></i> </a> 
        <!--<p>Awesome theme for your Business or Corporate site to showcase <br/>
          your product and service.</p>--> 
      </div>
    </div>
  </div>
</section>







<section id="work" class="page-section page">
  <div class="container text-center">
    <div class="heading">
      <h3>Our Services</h2>
      <p>we provide you with the best in class service</p>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div id="portfolio">
          <ul class="items list-unstyled clearfix animated fadeInRight showing" data-animation="fadeInRight" style="position: relative; height: 438px;">
          
        <li class="item branding" style=" position: absolute; "> 
      
            <a href="/portal/book.html"> 
      
            <img src="images/service/electrician.jpg" alt="">
            
              <div class="overlay"> 
              <span>electric</span> 

              </div>
              </a> 
          </li>
            <li class="item photography" style="position: absolute; left: 292px; top: 0px;"> 

            <a href="/portal/book.html" > 
      
            <img src="images/service/carpenter.jpg" alt="">
 
              <div class="overlay"> <span>Carpenter</span> </div>
              </a> </li>
            <li class="item branding" style="position: absolute; left: 585px; top: 0px;"> 
            <a href="/portal/book.html" > 
      
            <img src="images/service/computer.jpg" alt="">
 
              <div class="overlay"> <span>Computer maintenance</span> </div>
              </a> </li>
            <li class="item photography" style="position: absolute; left: 877px; top: 100px;"> 
            <a href="/portal/book.html" > 
      
            <img src="images/service/ac.jpg" alt="" style="top: 100px;">
 
              <div class="overlay"> <span>Air-conditioning maintenance</span> </div>
              </a> </li>
            <li class="item photography" style="position: absolute; left: 0px; top: 219px;"> 
            <a href="/portal/book.html" > 
      
            <img src="images/service/house.jpg" alt="">
 
              <div class="overlay"> <span>house cleaning</span> </div>
              </a> </li>
            <li class="item web" style="position: absolute; "> 
            <a href="/portal/book.html" > 
      
            <img src="images/service/home.jpg" alt="">
 
              <div class="overlay"> <span>home appliances maintenance</span> </div>
              </a> </li>
            <li class="item photography" style="position: absolute; left: 585px; top: 150px;"> 
            <a href="/portal/book.html" > 
      
            <img src="images/service/beauty.jpg" alt="">
 
              <div class="overlay"> <span>beauty saloon</span> </div>
              </a> </li>
            <li class="item web" style="position: absolute; left: 877px; top: 219px;"> 
             
            <a href="/portal/book.html" > 
      
            <img src="images/service/mechanic.jpg" alt="">
 
              <div class="overlay"> <span>automobiles repair</span> </div>
              </a> </li>
              
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>









<section id="team" class="page-section">
  <div class="container">
    <div class="heading text-center"> 
      <!-- Heading -->
      <h2>Our Team</h2>
      <p></p>
    </div>
    <!-- Team Member's Details -->
    <div class="team-content">
      <div class="row">
        <div class=" col-md-offset-2 col-md-3 col-sm-6 col-xs-6"> 
          <!-- Team Member -->
          <div class="team-member pDark"> 
            <!-- Image Hover Block -->
            <div class="member-img"> 
              <!-- Image  --> 
              <img class="img-responsive" src="images/mahir1.png" alt=""> </div>
            <!-- Member Details -->
            <h4>Khan Mahir Ali </h4>
            <!-- Designation --> 
            <span class="pos">CEO</span> </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6"> 
          <!-- Team Member -->
          <div class="team-member pDark"> 
            <!-- Image Hover Block -->
            <div class="member-img"> 
              <!-- Image  --> 
              <img class="img-responsive" src="images/arfat1.png" alt=""> </div>
            <!-- Member Details -->
            <h4>Shaikh arfat</h4>
            <!-- Designation --> 
            <span class="pos">fokat</span> </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6"> 
          <!-- Team Member -->
          <div class="team-member pDark"> 
            <!-- Image Hover Block -->
            <div class="member-img"> 
              <!-- Image  --> 
              <img class="img-responsive" src="images/Farhan.png" alt=""> </div>
            <!-- Member Details -->
            <h4>Shaikh Farhan</h4>
            <!-- Designation --> 
            <span class="pos">CTO</span> </div>
        </div>

        
  </div>
  <!--/.container--> 
</section>







<section id="aboutUs">
  <div class="container">
    <div class="heading text-center"> 
      <!-- Heading -->
      <h2 class="fadeInUp"><u>About Us</u></h2>
      <p></p>
    </div>
    <div class="row feature design">
      <div class="six columns right">
        <h3></h3>
        <p>
        our journey towards this company started 5 years ago,when we were just hanging out ,our CTO(Farhan shaikh)
        got a plan he said why dont we start to provide service to the people with the help of internet .We started providing services related to computer ,our computer maintenance expert Arfat shaikh gives an incredible service to our valuable customer.  
        </p>
        <p>
          Later we decide why dont we expand our buisness by providing more service ,so we appoint many expert from different fields and created a team .This team that we have made are very expert in thier work
        </p>
      </div>
      <div class="six columns feature-media left"> <img src="images/feature-img-1.png" alt=""> </div>
    </div>
  </div>
</section>




<section id="contact" class="contact-parlex">
  <div class="parlex-back">
    <div class="container">
      <div class="row">
        <div class="heading text-center"> 
          <!-- Heading -->
          <h2>Contact Us</h2>
          <p>In case of any inconvinence or feedback please feel free to contact us</p>
        </div>
      </div>
             <div class="row mrgn30">
  
                    <div class="col-sm-12 col-md-8"> 
        
  
    <form method="post" action="/portal/php/contact.php" role="form"> 
    
    <div class="control-group">
    
      <div class="controls">
    
        <input type="text" class="form-control" placeholder="Full Name"  name="cname" id="name" required
                  data-validation-required-message="Please enter your name" autofocus />
    

            <p class="help-block"></p>
    </div>
    
    </div>  
        <div class="control-group">
              <div class="controls">
            <input type="email" class="form-control" placeholder="Email" id="email" name="cemail" required
              data-validation-required-message="Please enter your email" />
    </div>
    </div>  

    <div class="control-group">
    <div class="controls">
  
    <textarea rows="10" cols="100" class="form-control" 
    placeholder="Message" id="message" required
    data-validation-required-message="Please enter your message" minlength="5" 
    data-validation-minlength-message="Min 5 characters" 
    maxlength="999" style="resize:none"  name="cmessage"></textarea>
    </div>
    </div>     
  
    <div id="success"> </div> <!-- For success/fail messages -->
    <button type="submit" name="submit" id="submit" class="btn btn-primary pull-right">Send</button>

    </form>
                    </div> 
                <div class="col-sm-12 col-md-4">
                    <h4>Address:</h4>
                    <address>
                        Portal Company<br>
                        kalsekar college. khandeshwar., 4000079<br>
                         Navi Mumbai ,maharshtra ,India
                        <br>
                    </address>
                    <h4>Phone:</h4>
                    <address>
                        +91-90293333567<br>
                    </address>
                </div>
            </div>
    </div>
    <div class="container">
      <div class="social text-center"> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-instagram "></i></a>  </div>
      <!--CLEAR FLOATS--> 
    </div>
    <!--/.container--> 
  </div>
</section>
<!--/.page-section-->
<section class="copyright">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 text-center"> Copyright 2016 | All Rights Reserved  by <a href="http://portal.com">www.portal.com</a> </div>
    </div>
    <!-- / .row --> 
  </div>
</section>

<a href="#top" class="topHome"><i class="fa fa-chevron-up fa-2x"></i></a> 

<!--[if lte IE 8]><script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script><![endif]--> 
<script src="js/modernizr-latest.js"></script> 
<script src="js/jquery-1.8.2.min.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/jquery.isotope.min.js" type="text/javascript"></script> 
<script src="js/fancybox/jquery.fancybox.pack.js" type="text/javascript"></script> 
<script src="js/jquery.nav.js" type="text/javascript"></script> 
<script src="js/jquery.fittext.js"></script> 
<script src="js/waypoints.js"></script> 
 <script src="contact/jqBootstrapValidation.js"></script>
 <script src="contact/contact_me.js"></script>
<script src="js/custom.js" type="text/javascript"></script> 
<script src="js/owl-carousel/owl.carousel.js"></script>


</body>
</html>