

<?php

require_once 'C:\xampp\htdocs\portal\php\function.php';



 if($_POST)
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $address=$_POST['address'];
    $contact=$_POST['contact'];

       if( !empty($name) && !empty($email) && !empty($address) && !empty($contact)){
        
     ?>
        <table>
            <tr>
                <td>Name</td>
                <td> <?php echo fix_name($name); ?> </td>
            </tr>
            

            <tr>
              <td>address</td>
              <td><?php echo $address; ?> </td>
            </tr>
            
            <tr>
              <td>conatct</td>
              <td><?php echo $contact; ?> </td>
            </tr>

            <tr>
              <td>email</td>
              <td><?php echo $email; ?> </td>
            </tr>
            
             

        </table>

<?php        
   }
 }
   else{
       echo "<span>Something is Missing!</span>";
       header('Refresh:2, url=/portal/newindex.html/#book');
   }

       

?>