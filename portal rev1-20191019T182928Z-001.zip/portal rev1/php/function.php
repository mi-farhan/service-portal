<?php

function validatepass($password,$cpassword)
{
 
 if ($_POST['password' != 'cpassword'])
 {
  echo
   ("Oops! Password did not match! Try again. ");
   header("Refresh:2,url:/project/html/newlogin.html");
}
}
function fix_name($username){
    
    $name=trim($username);
    $name=  ucfirst($username);
    $name=  addslashes($username);
    $name=htmlspecialchars($username);

    return $username;
}

function fix_email($email){
    
    $email=trim($email);
    $email=  strtolower($email);
    $email=  addslashes($email);
    
    return $email;
}



?>