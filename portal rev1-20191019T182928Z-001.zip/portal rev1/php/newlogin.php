<?php
session_start();
$con=mysqli_connect('localhost','root',''); 
    if(!$con){
      die("connection fail :".mysqli_connect_error());
    }

$query="create database if not exists test";
mysqli_query($con,$query);

$conn=mysqli_connect('localhost','root','','test');

  $query1 = "create table if not exists reg(
  name varchar(40) not null ,
  email varchar(60) not null  ,
  password varchar(200) not null ,
  time timestamp,
  PRIMARY KEY(email));";

  #$query1 .="insert into test(id,name,age) values (1,'farhan',18)";
  mysqli_multi_query($conn,$query1);
$email=$_POST['email'];
$password=md5($_POST['password']);
#$enpassword=md5($password);

require_once 'function.php';

    if($_POST['login-submit']) {
    
       
       if(!empty($email)&&!empty($password)){
          $queryboth="select * from reg where email='$email' and password='$password'";
          $queryemail="select * from reg where email='$email'";

          $resultboth = mysqli_query($conn,$queryboth);
          $resultemail = mysqli_query($conn,$queryemail);


          $countboth=mysqli_num_rows($resultboth);
          $countemail=mysqli_num_rows($resultemail);

          if ($countboth == 1){
            //echo "alert('Login Successfull')";
            
            $_SESSION['user']=$email;
            //$_SESSION['pass']=$password;
            echo "<script>
                alert('Logged in successfully ');

                window.location.href='../index.php';
              </script>";
            //echo "Username : $_SESSION[user]";

          }
          elseif($countemail == 1){
            echo "<script>
                alert('password is incorect');

                window.location.href='../newlogin.html';
              </script>";
             #echo "password is incorect";

          }
          elseif($countemail != 1){
            echo "<script>
                alert('Email Doesnt match with our databse');

                window.location.href='../newlogin.html';
              </script>";
            #echo "Email Doesnt match with our databse";
          }

      
     ?><!--
        <table>
            <tr>
                <td>userName</td>
                <td> <?php echo fix_name($username); ?> </td>
            </tr>
            

            <tr>
            	<td>password</td>
            	<td><?php echo $password; ?> </td>
            </tr>
             

        </table> -->
<?php   
  }     
    else{
       echo "<script>
                alert('Login Details Required');

                window.location.href='../index.php';
              </script>";
   }

  
}

else if($_POST['register-submit'])
{
    $username=$_POST['username'];
    $password=$_POST['password'];
    $enpass=md5($password);
    $cpassword=$_POST['confirm-password'];
    $email=$_POST['email'];

       if( /*!empty($username) && */!empty($email) && !empty($password) && !empty($cpassword)){
          $con=mysqli_connect('localhost','root',''); 
              if(!$con){
                die("connection fail :".mysqli_connect_error());
              }
          $query="create database if not exists test";
          mysqli_query($con,$query);
          
          #$conn=mysqli_connect('localhost','root','','test');
          $queryinsert="insert into reg(name,email,password) values('$username','$email','$enpass')";
          if(mysqli_query($conn,$queryinsert)){
            echo "<script>
                alert('Registered successfully ');

                window.location.href='../index.php';
              </script>";
          }else{
            echo "<script>
                alert('Registeration failed ');

                window.location.href='../newlogin.html';
              </script>";
          }


          #echo "<span>Registered Successfully</span>";
        
     ?>
     <!--
        <table>
            <tr>
                <td>userName</td>
                <td> <?php echo fix_name($username); ?> </td>
            </tr>
            

            <tr>
              <td>password</td>
              <td><?php echo $password; ?> </td>
            </tr>
            
            <tr>
              <td> confirm password</td>
              <td><?php echo $cpassword; ?> </td>
            </tr>

            <tr>
              <td>email</td>
              <td><?php echo $email; ?> </td>
            </tr>
            
             

        </table>
      -->
<?php        
   }
 }
   else{
    echo "<script>
                alert('Please Fill The Details');

                window.location.href='../newlogin.html';
              </script>";
       #echo "<span>Something is Missing!</span>";
       #header('Refresh:2, url=/portal/newlogin.html');
   }

       
mysqli_close($conn);
mysqli_close($con);
?>