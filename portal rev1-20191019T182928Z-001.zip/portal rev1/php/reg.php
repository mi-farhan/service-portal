<!DOCTYPE html>
<html>
<head></head>
<body>
<?php

$name =$_POST['name'];
$email =$_POST['email'];
$password =$_POST['password'];
$dbname = "test";

//echo $name;
//echo $email;
//echo $password;
$conn=mysqli_connect('localhost','root','root','test');

//$user ='$_post["name"]';

//$pas='$_post["password"]';

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$query="insert into reg(name,email,password) values('$name','$email','$password')";

//$select	= "select * from test1";

//echo $query;

//$result = mysqli_query($conn,$query);

if (mysqli_query($conn, $query)) {
    echo "<script>
			window.location.href='../html/reg_response.html';
		</script>";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

/*while($row = mysqli_fetch_array($result))
	echo "User :- ".$row['name']."<br>Email :- ".$row['email']."<br>Password :-".$row['password'];
*/
mysqli_close($conn);
?>
</body>
</html>
