

<?php

require_once 'C:\xampp\htdocs\portal\php\function.php';



 if($_POST)
{
    $name=$_POST['cname'];
    $email=$_POST['cemail'];
    $message=$_POST['cmessage'];
    

       if( !empty($name) && !empty($email) && !empty($message) ){
        
     ?>
        <table>
            <tr>
                <td>Name</td>
                <td> <?php echo fix_name($name); ?> </td>
            </tr>
            

            <tr>
              <td>message</td>
              <td><?php echo $message; ?> </td>
            </tr>
            
            <tr>
              <td>email</td>
              <td><?php echo $email; ?> </td>
            </tr>
            
             

        </table>

<?php        
   }
 }
 else{
   echo "<span>Something is Missing!</span>";
       header('Refresh:2, url=/project/html/index.html');
 }

       

?>