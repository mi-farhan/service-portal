<?php

$con=mysqli_connect('localhost','root','root'); 
    if(!$con){
      die("connection fail :".mysqli_connect_error());
    }

$query="create database if not exists test";
mysqli_query($con,$query);

$conn=mysqli_connect('localhost','root','root','test');

  $query1 = "create table if not exists booking(
  
  name varchar(200) not null ,
  email varchar(200) not null  ,
  address varchar(200) not null  ,
  contact varchar(200) not null  ,
  date date not null ,
  time timestamp);";

  #$query1 .="insert into test(id,name,age) values (1,'farhan',18)";
  mysqli_multi_query($conn,$query1);
$email=$_POST['email'];
require_once 'function.php';



 if($_POST)
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $address=$_POST['address'];
    $contact=$_POST['contact'];
    $date=$_POST['date'];
    $time=$_POST['time'];

         if( !empty($name) && !empty($email) && !empty($address) && !empty($contact && !empty($date) && !empty($time))){
            $queryinsert="insert into booking(name,email,address,contact,date,time) values('$name','$email','$address','$contact','$date','$time')";
          if(mysqli_query($conn,$queryinsert)){
            echo "<script>
                alert('Successfully Booked our service');

                window.location.href='../index.html';
              </script>";
          }
          else{
            echo "<script>
                alert('daya kuch to gadbad hai');

                window.location.href='../index.html';
              </script>";
          }
        
     ?><!--
        <table>
            <tr>
                <td>Name</td>
                <td> <?php echo fix_name($name); ?> </td>
            </tr>
            

            <tr>
              <td>address</td>
              <td><?php echo $address; ?> </td>
            </tr>
            
            <tr>
              <td>conatct</td>
              <td><?php echo $contact; ?> </td>
            </tr>

            <tr>
              <td>email</td>
              <td><?php echo $email; ?> </td>
            </tr>
            
              <tr>
              <td>date:</td>
              <td><?php echo $date; ?> </td>
            </tr>

            <tr>
              <td>time</td>
              <td><?php echo $time; ?> </td>
            </tr>
      
            
             

        </table>-->

<?php        
   }
 }
   else{
       echo "<span>Something is Missing!</span>";
       header('Refresh:2, url=/portal/book.html');
   }

       

?>