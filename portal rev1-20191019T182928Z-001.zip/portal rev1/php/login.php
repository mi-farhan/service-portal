<html>
<body>

<?php

if ($_POST){
$conn=mysqli_connect('localhost','root','','test');
$url = "../html/reg.html";
$email =$_POST["email"];

$password=$_POST["password"];

$queryboth="select * from reg where email='$email'and password='$password'";

$queryemail="select * from reg where email='$email'";

$querypass="select * from reg where password='$password'";

$resultboth = mysqli_query($conn,$queryboth);
$resultemail = mysqli_query($conn,$queryemail);
$resultpass= mysqli_query($conn,$querypass);

/*$rowboth=mysqli_fetch_array($resultboth,MYSQLI_ASSOC);
$rowemail=mysqli_fetch_array($resultemail);
$rowpass=mysqli_fetch_array($resultpass);
*/
$countboth=mysqli_num_rows($resultboth);
$countemail=mysqli_num_rows($resultemail);
$countpass=mysqli_num_rows($resultpass);

if ($countboth == 1){
	//echo "alert('Login Successfull')";
	session_start();

	$_SESSION['user']=$email;
	$_SESSION['pass']=$password;

	echo "<script>
			alert('Logged in successfully ');

			window.location.href='../html/index.html';
		</script>";
	//echo "Username : $_SESSION[user]";

}
elseif($countemail == 1){
	 echo "password is incorect";

}
elseif($countemail != 1){
	echo "Email Doesnt match with our databse";
// 	echo "<script language='javascript'>alert('Redirecting');</script>";
// 	function redirect() {
//     ob_start();
//     header('Location: ../html/reg.html ');
//     ob_end_flush();
//     die();
// }
	/*function redirect(){
	header("Refresh:2,url:www.google.com");
	}<html>
		<head></head>
		<body>
			<a href="www.google.com"></a>
		</body>
	</html>*/
	//redirect();
}
else{
	echo "Incorrect Email and Password";

}
/*elseif(mysqli_query($conn,$querypass)){
	echo "Email Id Doesnt match with our database";
}*/
/*while($row = mysqli_fetch_array($result))
	echo "User :- ".$row['user']."<br>Passwd :- ".$row['pwd']."<br>";
*/
}
else {
	echo "No Data Received";
}
mysqli_close($conn);

?>
</body>
</html>

